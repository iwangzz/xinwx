<?php
return array(
		"Name" => 'Name',
		"EMAIL" => 'Email',
		"TITLE" => 'Title',
		"CONTENT" => 'Content',
		"TIME" => 'Time',
);