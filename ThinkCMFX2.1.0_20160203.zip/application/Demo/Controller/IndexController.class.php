<?php
namespace Demo\Controller;
use Common\Controller\HomebaseController;

class IndexController extends HomebaseController{
	
	function index(){
		echo "hello";
	}
}